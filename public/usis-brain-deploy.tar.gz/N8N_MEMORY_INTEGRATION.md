# N8N Memory Integration Guide

## 🎯 目标
N8N不再管理记忆，只转发请求与发送结果，支持"清空记忆"命令。

---

## ✅ 需要的N8N调整（最小化改动）

### 1. **Call_Brain_Orchestrate 节点调整**

**当前Body参数（保持不变）：**
```json
{
  "text": "={{ $json.message?.text || $json.text || 'default' }}",
  "chat_type": "={{ $json.message?.chat?.type || $json.chat_type || 'group' }}",
  "user_id": "={{ $json.message?.from?.id || $json.user_id || 'system' }}"
}
```

**✅ 确认事项：**
- ✅ 已经只传递 `text`, `chat_type`, `user_id` 三个字段
- ✅ **不需要**传递 `memories` 字段（Brain自己从PostgreSQL读取）
- ✅ **不需要**修改此节点

---

### 2. **新增清空记忆分支（IF_ClearMemory）**

**在 Telegram_Trigger 之后添加：**

```
Telegram_Trigger → IF_ClearMemory
```

**IF_ClearMemory 条件：**
```javascript
={{ /清空记忆|reset memory|forget memory/i.test($json.message?.text || '') }}
```

**True 分支流程：**

1. **HTTP Request** 节点（Call_Clear_Memory）：
   - Method: `POST`
   - URL: `https://node-js-liqixi842.replit.app/brain/memory/clear`
   - Body:
     ```json
     {
       "user_id": "={{ $node['Telegram_Trigger'].json.message.from.id }}"
     }
     ```

2. **Telegram Send Message** 节点（Send_Clear_Confirmation）：
   - Chat ID: `={{ $node['Telegram_Trigger'].json.message.chat.id }}`
   - Text: `✅ 已清空你的历史记忆（仅影响个性化分析，不影响实时市场数据）`

3. **在此分支终止**（不再走 orchestrate 主流程）

**False 分支：**
- 连接到原有的 `Call_Brain_Orchestrate` 节点

---

### 3. **其余节点保持不变**

- ✅ Parse_Brain_Response
- ✅ IF_Needs_Heatmap
- ✅ Screenshot_Heatmap
- ✅ Merge_Screenshot
- ✅ Pack_Final_Message
- ✅ IF_Send_Photo
- ✅ Send_With_Photo / Send_Text_Only

**这些节点都不需要修改。**

---

## 🔄 完整流程图

```
Telegram_Trigger
    ↓
IF_ClearMemory
    ├─ True → Call_Clear_Memory → Send_Clear_Confirmation → [终止]
    └─ False → Call_Brain_Orchestrate
                    ↓
               Parse_Brain_Response
                    ↓
               IF_Needs_Heatmap
                    ├─ True → Screenshot_Heatmap → Normalize_Screenshot
                    └─ False → [直接传递]
                    ↓
               Merge_Screenshot
                    ↓
               Pack_Final_Message
                    ↓
               IF_Send_Photo
                    ├─ True → Send_With_Photo
                    └─ False → Send_Text_Only
```

---

## 🧪 回归测试

### **测试1：记忆功能**
```
1. 发送：盘前NVDA
2. 发送：盘中TSLA
3. 发送：个股AAPL
4. 发送：你能学习吗？
```

**预期结果：**
- 第4条回复中应包含"我会记住你最近的对话历史（最近3条）"
- Brain的console log应显示：`💾 用户历史记忆: 找到3条记录`

---

### **测试2：清空记忆**
```
1. 发送：清空记忆
2. 发送：你能学习吗？
```

**预期结果：**
- 第1条收到：`✅ 已清空你的历史记忆...`
- 第2条Brain的console log应显示：`💾 用户历史记忆: 找到0条记录`

---

### **测试3：重复消息修复验证**
```
发送：西班牙热力图
```

**预期结果：**
- **只收到1条**图文消息（不是2条或3条）

---

## 📋 N8N调整清单

- [ ] 添加 `IF_ClearMemory` 节点（Telegram_Trigger之后）
- [ ] 添加 `Call_Clear_Memory` 节点（HTTP Request到 `/brain/memory/clear`）
- [ ] 添加 `Send_Clear_Confirmation` 节点（Telegram发送确认）
- [ ] 确认 `Call_Brain_Orchestrate` 只传3个字段（text, chat_type, user_id）
- [ ] 确认 `IF_Send_Photo` 使用严格布尔判断（避免重复消息）
- [ ] 测试记忆功能（连续3次提问 + "你能学习吗？"）
- [ ] 测试清空记忆（"清空记忆" + 验证清空）

---

## 🎉 完成后的系统架构

```
┌─────────────────────────────────────────┐
│   Replit Brain (大脑 + 记忆一体)        │
│                                         │
│   ┌─────────────┐    ┌──────────────┐  │
│   │  6 AI模型   │───→│ PostgreSQL   │  │
│   │  智能分析   │    │  用户记忆    │  │
│   └─────────────┘    └──────────────┘  │
│         ↓                               │
│    返回final_analysis                   │
└─────────────────────────────────────────┘
         ↓
    N8N (执行器官)
    - 只转发请求（user_id）
    - 执行actions（热力图、新闻等）
    - 发送最终消息
```

---

## 💡 关键原则

1. **N8N = 笔记本 ❌**  →  **N8N = 执行器官 ✅**
2. **记忆归属：Brain的PostgreSQL数据库**
3. **N8N职责：转发请求 + 执行器官指令 + 发送结果**
4. **单一数据源：所有记忆由Brain管理，永久保存，Replit重启不丢失**
