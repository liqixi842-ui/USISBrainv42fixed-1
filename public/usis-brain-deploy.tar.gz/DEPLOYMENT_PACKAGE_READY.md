# ✅ USIS Brain 迁移包已就绪

**生成时间**: 2025-11-18  
**目标服务器**: 150.242.90.36 (Rocky 9)  
**生产域名**: https://myusis.net  
**Replit域名**: liqixi888.replit.app（保留为开发环境）

---

## 📦 迁移包内容

### 核心脚本（6个，已设置可执行权限）

```
migration/
├── 1_export_database.sh           [2.4K] 数据库导出
├── 2_restore_database.sh          [2.8K] 数据库恢复
├── 3_deploy_to_server.sh          [9.2K] 一键部署（核心）
├── 4_configure_nginx.sh           [3.2K] Nginx配置
├── 5_setup_https.sh               [2.6K] HTTPS证书
└── 6_verify_deployment.sh         [8.6K] 部署验证
```

### 文档（4个）

```
migration/
├── README.md                      [9.9K] 详细迁移指南
├── QUICK_START.txt               [6.8K] 5分钟快速入门
├── MIGRATION_CHECKLIST.md        [7.1K] 迁移检查清单
└── .env.production.template       [4.2K] 生产环境配置模板
```

### 代码修复

```
✅ v3_dev/services/devBotHandler.js
   第230行: 默认URL已更新为 https://myusis.net
```

---

## 🚀 立即开始迁移

### 方式 A: 快速入门（推荐新手）

```bash
# 打开快速指南
cat migration/QUICK_START.txt

# 按步骤执行（只需5分钟）
```

### 方式 B: 详细文档（推荐运维）

```bash
# 打开详细指南
less migration/README.md

# 或在浏览器中查看
```

### 方式 C: 检查清单（推荐团队）

```bash
# 使用检查清单跟踪进度
cat migration/MIGRATION_CHECKLIST.md
```

---

## 📋 迁移步骤预览

```
┌─────────────────────────────────────────────────────────┐
│ 1. 在 Replit 上导出数据库                               │
│    ./migration/1_export_database.sh                     │
│    [2分钟]                                              │
└─────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────┐
│ 2. 打包上传到服务器                                      │
│    tar + scp                                            │
│    [5分钟]                                              │
└─────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────┐
│ 3. 一键部署（自动化）                                    │
│    sudo ./migration/3_deploy_to_server.sh               │
│    [10分钟]                                             │
│    - 安装 Node.js, PostgreSQL, Nginx                   │
│    - 创建用户和数据库                                    │
│    - 安装依赖                                           │
│    - 配置 PM2                                           │
└─────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────┐
│ 4. 恢复数据库                                           │
│    sudo -u usis ./migration/2_restore_database.sh       │
│    [2分钟]                                              │
└─────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────┐
│ 5. 配置 Nginx                                           │
│    sudo ./migration/4_configure_nginx.sh                │
│    [2分钟]                                              │
└─────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────┐
│ 6. 配置 HTTPS                                           │
│    sudo ./migration/5_setup_https.sh                    │
│    [3分钟]                                              │
└─────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────┐
│ 7. 验证部署                                             │
│    ./migration/6_verify_deployment.sh                   │
│    [1分钟]                                              │
└─────────────────────────────────────────────────────────┘
                          ↓
                    ✅ 完成！
```

**总耗时**: 约 25-30 分钟

---

## 🔧 必需的环境变量

在服务器上配置 `/opt/usis-brain/.env`：

### ⚠️ 必须配置（系统无法启动）

```bash
# 核心
NODE_ENV=production
REPLIT_DEPLOYMENT_URL=https://myusis.net

# 数据库（自动配置）
DATABASE_URL=postgresql://usis_brain:密码@localhost:5432/usis_brain

# Telegram
TELEGRAM_BOT_TOKEN=从@BotFather获取

# AI（至少OpenAI）
OPENAI_API_KEY=sk-proj-...

# 金融数据（至少Finnhub）
FINNHUB_API_KEY=从finnhub.io获取

# PDF生成
DOC_RAPTOR_API_KEY=从docraptor.com获取
DOC_RAPTOR_TEST_MODE=false  # ⚠️ 必须为false
```

### ✅ 推荐配置（增强功能）

```bash
ANTHROPIC_API_KEY=...      # Claude长文分析
GOOGLE_AI_API_KEY=...      # Gemini快速响应
TWELVE_DATA_API_KEY=...    # 全球市场数据
BROWSERLESS_API_KEY=...    # 图表截图
```

### 📝 完整模板

```bash
cp migration/.env.production.template /opt/usis-brain/.env
nano /opt/usis-brain/.env  # 填入所有Keys
```

---

## ✅ 代码修复确认

### devBotHandler.js 已更新

**文件**: `v3_dev/services/devBotHandler.js`  
**行号**: 230  
**修改前**:
```javascript
'https://liqixi888.replit.app'
```

**修改后**:
```javascript
'https://myusis.net'
```

**影响**: Telegram Bot生成研报时将默认调用新域名

---

## 📊 系统架构对比

### 迁移前（Replit）

```
用户 → liqixi888.replit.app → Replit Reserved VM
                               ├─ Node.js (内置)
                               ├─ PostgreSQL (Neon)
                               └─ HTTPS (自动)
```

### 迁移后（自有服务器）

```
用户 → myusis.net → 150.242.90.36
                    ├─ Nginx (反向代理)
                    ├─ PM2 → Node.js
                    ├─ PostgreSQL 15
                    └─ Certbot (Let's Encrypt)
```

### Replit新角色（保留）

```
开发者 → liqixi888.replit.app → 开发/测试环境
                                 ├─ 代码调试
                                 ├─ 功能测试
                                 └─ 可选：反向代理到生产服务器
```

---

## 🔒 安全清单

- [x] 默认URL已更新为 myusis.net
- [ ] .env 权限设为 600
- [ ] PostgreSQL 仅监听 localhost
- [ ] 防火墙仅开放 22, 80, 443
- [ ] SSH密钥登录（禁用密码）
- [ ] SSL证书自动续期
- [ ] 定期数据库备份
- [ ] 敏感日志已清理

---

## 📱 迁移后操作

### 1. 更新 Telegram Bot Webhook

```bash
curl https://api.telegram.org/bot<YOUR_TOKEN>/setWebhook?url=https://myusis.net/webhook/<YOUR_TOKEN>
```

### 2. 更新 N8N 工作流

将所有工作流中的 `liqixi888.replit.app` 替换为 `myusis.net`

### 3. 配置监控（可选）

- UptimeRobot: https://myusis.net/health（每5分钟）
- 告警邮箱: 您的邮箱

### 4. 定期备份

```bash
# 添加到 crontab（每天凌晨2点）
0 2 * * * cd /opt/usis-brain && ./migration/1_export_database.sh
```

---

## 🆘 故障排查

### 应用无法启动

```bash
# 查看PM2日志
sudo -u usis pm2 logs

# 手动启动测试
cd /opt/usis-brain
node index.js
```

### 数据库连接失败

```bash
# 测试连接
psql postgresql://usis_brain:密码@localhost:5432/usis_brain

# 检查PostgreSQL状态
sudo systemctl status postgresql
```

### Nginx 502错误

```bash
# 检查Node.js是否运行
sudo -u usis pm2 status

# 检查端口监听
netstat -tuln | grep 3000
```

### SSL证书失败

```bash
# 检查DNS
dig myusis.net

# 测试HTTP
curl http://myusis.net/health

# Dry-run测试
sudo certbot --nginx -d myusis.net --dry-run
```

---

## 📞 获取帮助

### 详细文档
```bash
cat migration/README.md
```

### 检查清单
```bash
cat migration/MIGRATION_CHECKLIST.md
```

### 快速参考
```bash
cat migration/QUICK_START.txt
```

---

## 🎯 下一步行动

**现在就开始迁移？**

### 步骤 1: 导出数据库（在Replit上）
```bash
cd /home/runner/USIS_Brain
./migration/1_export_database.sh
```

### 步骤 2: 查看快速指南
```bash
cat migration/QUICK_START.txt
```

### 步骤 3: 开始部署
按照 `QUICK_START.txt` 或 `README.md` 执行剩余步骤

---

## ✨ 迁移完成后

您将拥有：
- ✅ 完全控制的生产服务器（150.242.90.36）
- ✅ 自定义域名（myusis.net）
- ✅ 自动续期的HTTPS证书
- ✅ 专业的进程管理（PM2）
- ✅ 高性能反向代理（Nginx）
- ✅ 完整的数据库备份
- ✅ 保留Replit作为开发环境

**成本对比**:
- Replit Reserved VM: $20-160/月
- 自有服务器: 仅服务器成本（无平台费用）

---

## 📋 验证成功的标志

```bash
✅ curl https://myusis.net/health
   → { "ok": true, "status": "ok" }

✅ curl https://myusis.net/v3/report/test
   → { "ok": true, "env": "v3-dev", ... }

✅ curl https://myusis.net/v3/report/AAPL?format=json
   → 完整的20页研报JSON

✅ sudo -u usis pm2 status
   → usis-brain | online | 0

✅ ./migration/6_verify_deployment.sh
   → ✅ 所有测试通过!
```

---

**准备好了吗？立即开始迁移！🚀**

参考文档: `migration/README.md` 或 `migration/QUICK_START.txt`
