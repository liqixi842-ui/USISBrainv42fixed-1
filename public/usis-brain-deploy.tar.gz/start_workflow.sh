#!/bin/bash
export ENABLE_TELEGRAM=true
export ENABLE_NEWS_SYSTEM=true
node index.js
