# v3-dev 研报功能 v1 测试指南

**功能状态:** ✅ 代码完成，等待部署测试  
**创建时间:** 2025-11-15  
**版本:** v1.0-test

---

## 📋 功能概述

在 v3-dev 环境中实现了研报功能 v1（测试版），包括：

1. **HTTP API endpoints**
   - `GET /v3/report/test` - 静态示例研报
   - `GET /v3/report/:symbol` - 动态生成研报

2. **Telegram Bot 命令**
   - `/report` - 显示使用帮助
   - `/report [SYMBOL]` - 生成指定股票的研报

3. **AI 驱动**
   - 使用 GPT-4o-mini 生成研报内容
   - 15秒超时保护
   - Fallback 机制确保可用性

---

## 🧪 测试清单

### 【第1步】HTTP API 测试

#### Test 1.1: 静态示例研报
```bash
curl https://liqixi888.replit.app/v3/report/test
```

**预期响应:**
```json
{
  "ok": true,
  "env": "v3-dev",
  "type": "equity_research_report_mock",
  "symbol": "AAPL",
  "generated_at": "2025-11-15T...",
  "sections": {
    "summary": "...",
    "business": "...",
    "valuation": "...",
    "technical": "...",
    "risks": "..."
  },
  "rating": "BUY",
  "target_price": "$190",
  "horizon": "12个月",
  "disclaimer": "..."
}
```

**验证点:**
- ✅ HTTP 200 状态码
- ✅ 返回完整的 JSON 结构
- ✅ `env` 字段为 "v3-dev"
- ✅ 包含所有必需字段

---

#### Test 1.2: 动态生成 AAPL 研报
```bash
curl https://liqixi888.replit.app/v3/report/AAPL
```

**预期响应:**
```json
{
  "ok": true,
  "env": "v3-dev",
  "version": "1.0-test",
  "symbol": "AAPL",
  "generated_at": "2025-11-15T...",
  "report": {
    "title": "AAPL 研究报告（测试版）",
    "symbol": "AAPL",
    "rating": "BUY | HOLD | SELL",
    "horizon": "短期 | 中期 | 长期",
    "summary": "...",
    "drivers": ["...", "..."],
    "risks": ["...", "..."],
    "technical_view": "...",
    "price_info": {
      "current": "...",
      "change": "...",
      "change_percent": "...",
      "high": "...",
      "low": "...",
      "volume": "..."
    },
    "generated_at": "...",
    "model_used": "gpt-4o-mini",
    "latency_ms": 1234,
    "disclaimer": "..."
  }
}
```

**验证点:**
- ✅ HTTP 200 状态码
- ✅ `ok: true`
- ✅ `report` 对象存在
- ✅ 包含 AI 生成的分析内容
- ✅ `model_used` 为 "gpt-4o-mini" 或 "fallback"
- ✅ 响应时间 < 20 秒

---

#### Test 1.3: 测试其他股票代码
```bash
# Tesla
curl https://liqixi888.replit.app/v3/report/TSLA

# NVIDIA
curl https://liqixi888.replit.app/v3/report/NVDA

# Microsoft
curl https://liqixi888.replit.app/v3/report/MSFT
```

**验证点:**
- ✅ 所有请求都成功返回
- ✅ 每个股票的研报内容不同
- ✅ Symbol 字段正确大写

---

### 【第2步】Telegram 开发 Bot 测试

#### Test 2.1: 测试 /report 命令（无参数）

**操作:** 在开发 Bot 中发送
```
/report
```

**预期响应:**
```
📊 请提供股票代码

格式：/report AAPL

示例：
/report AAPL
/report TSLA
/report NVDA
```

**验证点:**
- ✅ Bot 回复使用帮助
- ✅ 包含正确的命令格式说明
- ✅ 包含示例

---

#### Test 2.2: 测试 /report AAPL 命令

**操作:** 在开发 Bot 中发送
```
/report AAPL
```

**预期响应:**（分两条消息）

**消息1（立即）:**
```
🔬 正在生成 AAPL 研报（v3-dev测试版）...

请稍候...
```

**消息2（5-15秒后）:**
```
📊 USIS·研报测试版（v3-dev）

标的：AAPL
评级：🟢 BUY
时间范围：中期

💰 价格信息
• 当前价：175.50
• 涨跌：2.30 (1.33%)
• 最高/最低：176.20 / 173.80

📈 核心观点
[AI生成的分析内容]

🎯 驱动因素
1. [因素1]
2. [因素2]
3. [因素3]

⚠️ 风险提示
1. [风险1]
2. [风险2]

📉 技术面
[技术分析内容]

---
⏱ 生成时间：1234ms
🤖 AI模型：gpt-4o-mini
🔬 环境：v3-dev (测试版)

免责声明：⚠️ 本报告为 v3-dev 测试版本...
```

**验证点:**
- ✅ 先显示"正在生成"消息
- ✅ 5-15秒内收到完整研报
- ✅ 研报格式正确，包含所有章节
- ✅ 评级显示正确的emoji
- ✅ 包含价格信息
- ✅ 包含免责声明
- ✅ 标注 v3-dev 环境

---

#### Test 2.3: 测试其他股票

**操作:** 依次发送
```
/report TSLA
/report NVDA
/report MSFT
```

**验证点:**
- ✅ 每只股票都能生成研报
- ✅ 内容各不相同
- ✅ 评级可能不同
- ✅ 所有格式一致

---

#### Test 2.4: 测试 /help 命令更新

**操作:** 在开发 Bot 中发送
```
/help
```

**预期响应:**
```
📚 v3-dev Bot Help

/test - Test connectivity
/status - Bot status
/v3 - v3-dev info
/report [SYMBOL] - Generate research report (v1 test)
/help - This message
```

**验证点:**
- ✅ 包含 `/report` 命令说明
- ✅ 其他命令保持不变

---

### 【第3步】生产 Bot 隔离验证

#### Test 3.1: 确认生产 Bot 不受影响

**操作:** 在生产 Bot 中发送
```
/analyze AAPL
```

**预期响应:**
```
[完整的 v2-stable 分析报告]
• 不包含"v3-dev"字样
• 不包含"测试版"字样
• 使用原有的分析格式
```

**验证点:**
- ✅ 生产 Bot 正常工作
- ✅ 没有"v3-dev"或"测试版"标记
- ✅ 使用 v2-stable 的分析逻辑

---

#### Test 3.2: 生产 Bot 不识别 /report 命令

**操作:** 在生产 Bot 中发送
```
/report AAPL
```

**预期响应:**
```
[原有的默认回复，或不识别命令的提示]
```

**验证点:**
- ✅ 不生成研报
- ✅ 不显示 v3-dev 相关内容
- ✅ 按原有逻辑处理（可能当作普通消息）

---

## 📊 测试结果记录表

| 测试项 | 预期结果 | 实际结果 | 状态 | 备注 |
|--------|----------|----------|------|------|
| HTTP /v3/report/test | 返回静态示例 | - | ⏳ | 等待测试 |
| HTTP /v3/report/AAPL | 生成动态研报 | - | ⏳ | 等待测试 |
| HTTP /v3/report/TSLA | 生成动态研报 | - | ⏳ | 等待测试 |
| Bot /report | 显示帮助 | - | ⏳ | 等待测试 |
| Bot /report AAPL | 生成研报 | - | ⏳ | 等待测试 |
| Bot /help | 包含 /report | - | ⏳ | 等待测试 |
| 生产Bot /analyze | v2-stable正常 | - | ⏳ | 等待测试 |
| 生产Bot /report | 不生成v3研报 | - | ⏳ | 等待测试 |

---

## 🔧 已实现的文件

### 新增文件 (3个):
1. `v3_dev/services/reportService.js` (215行)
   - AI 驱动的研报生成服务
   - GPT-4o-mini 模型调用
   - Fallback 机制

2. `v3_dev/routes/report.js` (121行)
   - Express 路由处理
   - `/test` 和 `/:symbol` endpoints
   - 数据获取和错误处理

3. `v3_dev/REPORT_FEATURE_V1_TESTING.md` (本文件)
   - 完整测试指南

### 修改文件 (2个):
1. `v3_dev/routes/index.js`
   - 挂载 `/report` 路由

2. `v3_dev/services/devBotHandler.js`
   - 添加 `/report` 命令处理
   - Telegram 消息格式化
   - 错误处理

---

## 🎯 功能特性

### ✅ 已实现
- AI 驱动的研报生成（GPT-4o-mini）
- 股票价格数据获取
- 评级系统（STRONG_BUY, BUY, HOLD, SELL, STRONG_SELL）
- 时间范围（短期、中期、长期）
- 驱动因素分析
- 风险提示
- 技术面分析
- Telegram 友好格式
- 超时保护（15秒）
- Fallback 机制
- 完全隔离于 v2-stable

### 🚧 待完善（v2版本）
- 更深入的基本面分析
- 历史价格走势分析
- 行业对比分析
- 财务数据整合
- PDF 报告导出
- 报告历史记录
- 自定义评级标准

---

## ⚠️ 注意事项

1. **隔离性确认**
   - 所有代码在 `v3_dev/` 目录下
   - 不修改任何 v2-stable 文件
   - 只在开发 Bot 生效

2. **API 成本**
   - 每次调用约 0.001-0.005 美元
   - 使用 GPT-4o-mini（成本最低）
   - 15秒超时保护

3. **数据时效性**
   - 依赖实时行情数据
   - 如果数据获取失败，使用 mock 数据
   - AI 分析基于有限数据

4. **免责声明**
   - 测试版功能，不构成投资建议
   - 数据可能不完整或延迟
   - 仅用于开发测试

---

## 📞 问题排查

### 问题1: HTTP 404 错误
**原因:** 路由未加载  
**解决:** 重启应用或重新部署

### 问题2: Bot 不响应 /report
**原因:** 代码未生效  
**解决:** 确认是开发 Bot (8552043622)，重启应用

### 问题3: 研报生成超时
**原因:** AI API 响应慢  
**解决:** 正常现象，会返回 fallback 研报

### 问题4: 价格数据为 N/A
**原因:** 数据源不可用  
**解决:** 会使用 mock 数据继续生成

---

**测试准备完成，等待部署后验证！** 🚀
